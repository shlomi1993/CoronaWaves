# Shlomi Ben-Shushan 311408264
# Itamar Laredo 311547087


from app import App


if __name__ == '__main__':
    app = App()
    app.mainloop()
